bad = ["1", "11", "12", "20", "2", "3", "4"]

single_digit = []
double_digit = []
triple_digit = []
quadruple_digit = []

for item in bad:
    if len(item) == 1:
        single_digit.append(item)
    elif len(item) == 2:
        double_digit.append(item)
    elif len(item) == 3:
        triple_digit.append(item)
    elif len(item) == 4:
        quadruple_digit.append(item)

good = single_digit + double_digit + triple_digit + quadruple_digit
print(good)